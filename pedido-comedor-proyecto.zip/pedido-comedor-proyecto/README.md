# Escuela N°54 - Comedor Escolar

App React lista para desplegar en Netlify desde GitHub.