
import React from "react";

export default function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>🍽️ Escuela N°54 - Comedor Escolar</h1>
      <p>App base React lista para subir a GitHub y conectar con Netlify.</p>
    </div>
  );
}
